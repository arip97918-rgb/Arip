module.exports = {
  tokenBot: "https://whatsapp.com/channel/0029Vb2E8NH4SpkD9oqVTo0d",
  ownerID: "6283849409678",
};
