global.menu = `
 ᴀᴅᴅ-ᴍᴇɴᴜ
» /addptid time
» /dept id time
» /addprem id time
» /delprem id
» /addvip id time 
» /delvip id
» /addmod id time
» /delmod id
» /listvip
» /listmod
⦿ sᴇɴᴅᴇʀ-ᴍᴇɴᴜ 
» /connect nomor
» /selsension
» /setcd
global.bugx
⚉ 𝗕 𝗨 𝗚 - 𝗠 𝗘 𝗡 𝗨 🦠
⦿ VOICE XIP
» /delxy 
» /xploit 
» /xcefix 
» /blnakrs
» /deltc
» /xpow 

⦿ TZY ZIP
» /view 
» /iosfe
» /zerso
» /crios

global.md
⌑ /cekbio - Cek bio WhatsApp 
⌑ /biogrup - Cek bio grup 
⌑ /unbanhard - Unban WhatsApp 
⌑ /unban - Unban permanen 
⌑ /cekkontak - Get kontak 
⌑ /cekkontaks - Nama kontak
⌑ /cekdetail - Cek detail bio
⌑ /cekbisnis - Cek bisnis
⌑ /cekgaleri - Cek galeri WA 
⌑ /cekprofil - Cek profil
⌑ /cekmedia - Download media
⌑ /iqc - Screenshot To iPhone
⌑ /waifu - Anime waifu
⌑ /getnsfw - gambar 
⌑ /telkon - repy photo
⌑ /recommend - Recommendations
⌑ /character - Cari karakter anime
⌑ /nsfwwaifu - Neko 18+
⌑ /anime - Cari judul anime 
⌑ /cekerroremail - Cek error email 
⌑ /cekbanyakemail - Temp email 
⌑ /cekdomainemail - Domain email 
⌑ /testemail - Test email
⌑ /trending - Trending
⌑ /lyrics - judul lagu
⌑ /tiktokdl - download tt
⌑ /searchsong - arti x lagu
⌑ /nikparse - NIK 
⌑ /doxxingip - ip
`